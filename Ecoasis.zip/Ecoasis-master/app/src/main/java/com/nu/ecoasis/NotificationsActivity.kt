package com.nu.ecoasis

import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.Timestamp
import com.google.firebase.firestore.ListenerRegistration
import com.nu.ecoasis.databinding.ActivityNotificationsBinding
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class NotificationsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityNotificationsBinding
    private lateinit var firestoreManager: FirestoreManager
    private lateinit var adapter: NotificationsAdapter

    private var notificationsListener: ListenerRegistration? = null
    private val notificationsList = mutableListOf<NotificationItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        firestoreManager = FirestoreManager()
        setupRecyclerView()
        setupClickListeners()
        setupFirestoreListener()
        updateButtonStates()
    }

    private fun setupRecyclerView() {
        adapter = NotificationsAdapter(notificationsList)
        binding.notificationsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.notificationsRecyclerView.adapter = adapter
    }

    private fun setupClickListeners() {
        binding.backbutton.setOnClickListener {
            finish()
        }

        binding.clearAllBtn.setOnClickListener {
            clearAllNotifications()
        }
    }

    private fun setupFirestoreListener() {
        notificationsListener = firestoreManager.db.collection("notifications")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) {
                    // Handle error
                    return@addSnapshotListener
                }

                snapshot?.let { querySnapshot ->
                    notificationsList.clear()
                    for (document in querySnapshot.documents) {
                        val title = document.getString("title") ?: "Notification"
                        val content = document.getString("content") ?: ""
                        val timestamp = document.getTimestamp("timestamp")?.toDate() ?: Date()
                        val id = document.id

                        notificationsList.add(NotificationItem(id, title, content, timestamp))
                    }

                    adapter.notifyDataSetChanged()
                    updateEmptyState()
                }
            }
    }

    private fun updateEmptyState() {
        if (notificationsList.isEmpty()) {
            binding.notificationsRecyclerView.visibility = View.GONE
            binding.emptyStateCard.visibility = View.VISIBLE
        } else {
            binding.notificationsRecyclerView.visibility = View.VISIBLE
            binding.emptyStateCard.visibility = View.GONE
        }
    }

    private fun clearAllNotifications() {
        if (notificationsList.isEmpty()) return

        // Delete all notifications from Firestore
        val batch = firestoreManager.db.batch()
        notificationsList.forEach { notification ->
            val docRef = firestoreManager.db.collection("notifications").document(notification.id)
            batch.delete(docRef)
        }

        batch.commit().addOnCompleteListener {
            // List will update automatically via the listener
            if (it.isSuccessful) {
                // Show confirmation or handle success
            }
        }
    }

    private fun deleteNotification(notificationId: String) {
        firestoreManager.db.collection("notifications").document(notificationId)
            .delete()
            .addOnSuccessListener {
                // Item will be removed automatically via the listener
            }
            .addOnFailureListener { exception ->
                // Handle error
            }
    }

    private fun updateButtonStates() {
        val isNightMode = isNightModeEnabled()
        binding.clearAllBtn.isActivated = isNightMode
        binding.backbutton.isActivated = isNightMode
    }

    private fun isNightModeEnabled(): Boolean {
        val currentNightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return currentNightMode == Configuration.UI_MODE_NIGHT_YES
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateButtonStates()
    }

    override fun onDestroy() {
        super.onDestroy()
        notificationsListener?.remove()
    }

    data class NotificationItem(
        val id: String,
        val title: String,
        val content: String,
        val timestamp: Date
    )

    inner class NotificationsAdapter(
        private val items: List<NotificationItem>
    ) : RecyclerView.Adapter<NotificationsAdapter.NotificationViewHolder>() {

        inner class NotificationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val title: TextView = itemView.findViewById(R.id.notificationTitle)
            val content: TextView = itemView.findViewById(R.id.notificationContent)
            val time: TextView = itemView.findViewById(R.id.notificationTime)

            val statusText: TextView = itemView.findViewById(R.id.statusText)

            init {
                itemView.setOnLongClickListener {
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        showDeleteConfirmation(items[position])
                        true
                    } else {
                        false
                    }
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotificationViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_notification, parent, false)
            return NotificationViewHolder(view)
        }

        override fun onBindViewHolder(holder: NotificationViewHolder, position: Int) {
            val item = items[position]

            holder.title.text = item.title
            holder.content.text = item.content
            holder.time.text = getTimeAgo(item.timestamp)

            // Set appropriate styling based on notification type
            when {
                item.title.contains("pH", ignoreCase = true) -> {
                    setNotificationStyle(holder, R.color.red_error, "pH Level Alert")
                }
                item.title.contains("Nutrient", ignoreCase = true) -> {
                    setNotificationStyle(holder, R.color.red_error, "Nutrient Alert")
                }
                item.title.contains("Normal", ignoreCase = true) -> {
                    setNotificationStyle(holder, R.color.green_success, "System Normal")
                }
                else -> {
                    setNotificationStyle(holder, R.color.green_success, "System Update")
                }
            }
        }

        private fun setNotificationStyle(holder: NotificationViewHolder, colorRes: Int, statusText: String) {
            val color = ContextCompat.getColor(this@NotificationsActivity, colorRes)

            holder.statusText.text = statusText
        }

        override fun getItemCount(): Int = items.size

        private fun getTimeAgo(date: Date): String {
            val now = Date()
            val diff = now.time - date.time

            return when {
                diff < TimeUnit.MINUTES.toMillis(1) -> "Just now"
                diff < TimeUnit.HOURS.toMillis(1) -> {
                    val minutes = TimeUnit.MILLISECONDS.toMinutes(diff)
                    "$minutes min ago"
                }
                diff < TimeUnit.DAYS.toMillis(1) -> {
                    val hours = TimeUnit.MILLISECONDS.toHours(diff)
                    "$hours h ago"
                }
                else -> {
                    val days = TimeUnit.MILLISECONDS.toDays(diff)
                    "$days d ago"
                }
            }
        }

        private fun showDeleteConfirmation(notification: NotificationItem) {
            androidx.appcompat.app.AlertDialog.Builder(this@NotificationsActivity)
                .setTitle("Delete Notification")
                .setMessage("Are you sure you want to delete this notification?")
                .setPositiveButton("Delete") { dialog, which ->
                    deleteNotification(notification.id)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }
}