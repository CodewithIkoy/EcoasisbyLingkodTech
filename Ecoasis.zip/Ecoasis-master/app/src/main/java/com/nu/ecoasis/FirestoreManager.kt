package com.nu.ecoasis

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.tasks.await
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Date
import kotlin.text.get

private fun Double.roundToDecimalPlace(decimalPlaces: Int): Double {
    if (this.isNaN() || this.isInfinite()) {
        return this
    }
    return BigDecimal(this).setScale(decimalPlaces, RoundingMode.HALF_UP).toDouble()
}


data class PlantPreset(
    val name: String = "",
    val minPH: Double = 0.0,
    val maxPH: Double = 0.0,
    val minPPM: Int = 0,
    val maxPPM: Int = 0
) {
    constructor() : this("", 0.0, 0.0, 0, 0)
}
class FirestoreManager {

    val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val sensorCollection by lazy { db.collection("ecoasis") }
    val PH_ABS_MIN = 1.0
    val PH_ABS_MAX = 14.0
    val TDS_ABS_MIN = 0
    val TDS_ABS_MAX = 1500

    private val statusCollection by lazy { db.collection("ecoasis") }

    data class StatusReading(
        val status: StatusFields = StatusFields()
    ) {
        constructor() : this(StatusFields())

        data class StatusFields(
            val ph: Int = 0,
            val tds: Int = 0
        ) {
            constructor() : this(0, 0)
        }
    }
    data class CalibrationDocument(
        val request: Map<String, Boolean> = emptyMap(),
        val values: Map<String, Double> = emptyMap(),
        val complete: Boolean = false
    ) {
        constructor() : this(emptyMap(), emptyMap(), false)
    }
    suspend fun setCalibrationComplete(isComplete: Boolean): Boolean {
        return try {
            db.collection("ecoasis").document("calibration")
                .update("complete", isComplete)
                .await()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    suspend fun updateCalibrationCompletion(): Boolean {
        return try {
            val document = db.collection("ecoasis").document("calibration").get().await()
            if (document.exists()) {
                val requestMap = document.get("request") as? Map<String, Boolean> ?: emptyMap()

                val ph4Calibrated = requestMap["ph4"] == false
                val ph7Calibrated = requestMap["ph7"] == false
                val ph9Calibrated = requestMap["ph9"] == false

                val isComplete = ph4Calibrated && ph7Calibrated && ph9Calibrated

                val currentComplete = document.getBoolean("complete") ?: false
                if (isComplete != currentComplete) {
                    db.collection("ecoasis").document("calibration")
                        .update("complete", isComplete)
                        .await()
                }

                isComplete
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    suspend fun getCalibrationCompletion(): Boolean {
        return try {
            val document = db.collection("ecoasis").document("calibration").get().await()
            document.getBoolean("complete") ?: false
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun getCalibrationCompletionRealTime(onUpdate: (Boolean) -> Unit) {
        db.collection("ecoasis").document("calibration").addSnapshotListener { snapshot, error ->
            if (error != null) {
                onUpdate(false)
                return@addSnapshotListener
            }

            val isComplete = snapshot?.getBoolean("complete") ?: false
            onUpdate(isComplete)
        }
    }
    data class CalibrationStatus(
        val ph_v: Double = 0.0,
        val status: StatusFields = StatusFields(),
        val calibrationComplete: Boolean = false
    ) {
        constructor() : this(0.0, StatusFields(), false)

        data class StatusFields(
            val calibrated: Boolean = false
        ) {
            constructor() : this(false)
        }

        fun getCalibrated(): Boolean = this.status.calibrated
        fun getPhVoltage(): Double = this.ph_v

    }
    fun getCalibrationStatusRealTime(onUpdate: (CalibrationStatus?) -> Unit) {
        db.collection("ecoasis").document("readings").addSnapshotListener { snapshot, error ->
            if (error != null) {
                onUpdate(null)
                return@addSnapshotListener
            }

            val calibrationStatus = snapshot?.toObject(CalibrationStatus::class.java)

            getCalibrationCompletionRealTime { isComplete ->
                val updatedStatus = calibrationStatus?.copy(calibrationComplete = isComplete)
                onUpdate(updatedStatus)
            }
        }
    }
    suspend fun getStatusReading(): StatusReading? {
        return try {
            db.collection("ecoasis").document("readings").get().await()
                .toObject(StatusReading::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun getStatusReadingRealTime(onUpdate: (StatusReading?) -> Unit) {
        db.collection("ecoasis").document("readings").addSnapshotListener { snapshot, error ->
            if (error != null) {
                onUpdate(null)
                return@addSnapshotListener
            }
            val statusReading = snapshot?.toObject(StatusReading::class.java)
            onUpdate(statusReading)
        }
    }

    fun getPumpStatusRealTime(onUpdate: (StatusData?) -> Unit) {
        statusCollection.document("status").addSnapshotListener { snapshot, error ->
            if (error != null) {
                onUpdate(null)
                return@addSnapshotListener
            }

            val statusData = snapshot?.toObject(StatusData::class.java)
            onUpdate(statusData)
        }
    }

    suspend fun getPumpStatus(): StatusData? {
        return try {
            statusCollection.document("status").get().await().toObject(StatusData::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun getRangeSettings(
        onSuccess: (phMin: Double, phMax: Double, tdsMin: Int, tdsMax: Int) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val docRef = db.collection("ecoasis").document("settings")

        docRef.get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val phMin = clampPhValue(document.getDouble("ph_min") ?: PH_ABS_MIN)
                    val phMax = clampPhValue(document.getDouble("ph_max") ?: PH_ABS_MAX)
                    val tdsMin = clampTdsValue(document.getLong("tds_min")?.toInt() ?: TDS_ABS_MIN)
                    val tdsMax = clampTdsValue(document.getLong("tds_max")?.toInt() ?: TDS_ABS_MAX)

                    onSuccess(phMin, phMax, tdsMin, tdsMax)
                } else {
                    onSuccess(PH_ABS_MIN, PH_ABS_MAX, TDS_ABS_MIN, TDS_ABS_MAX)
                }
            }
            .addOnFailureListener { exception ->
                onFailure(exception)
            }
    }

    fun listenForRangeSettings(
        onUpdate: (phMin: Double, phMax: Double, tdsMin: Int, tdsMax: Int) -> Unit,
        onError: (FirebaseFirestoreException) -> Unit
    ): ListenerRegistration {
        val docRef = db.collection("ecoasis").document("settings")

        return docRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                onError(error)
                return@addSnapshotListener
            }

            if (snapshot != null && snapshot.exists()) {
                val phMin = clampPhValue(snapshot.getDouble("ph_min") ?: PH_ABS_MIN)
                val phMax = clampPhValue(snapshot.getDouble("ph_max") ?: PH_ABS_MAX)
                val tdsMin = clampTdsValue(snapshot.getLong("tds_min")?.toInt() ?: TDS_ABS_MIN)
                val tdsMax = clampTdsValue(snapshot.getLong("tds_max")?.toInt() ?: TDS_ABS_MAX)
                onUpdate(phMin, phMax, tdsMin, tdsMax)
            } else {
                onUpdate(PH_ABS_MIN, PH_ABS_MAX, TDS_ABS_MIN, TDS_ABS_MAX)
            }
        }
    }

    fun saveRangeSettings(
        phMin: Double,
        phMax: Double,
        tdsMin: Int,
        tdsMax: Int,
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val clampedPhMin = clampPhValue(phMin)
        val clampedPhMax = clampPhValue(phMax)

        val clampedTdsMin = clampTdsValue(tdsMin)
        val clampedTdsMax = clampTdsValue(tdsMax)

        if (clampedPhMin >= clampedPhMax) {
            onFailure(IllegalArgumentException("pH Min must be less than pH Max"))
            return
        }

        if (clampedTdsMin >= clampedTdsMax) {
            onFailure(IllegalArgumentException("TDS Min must be less than TDS Max"))
            return
        }

        val settingsData = hashMapOf(
            "ph_min" to clampedPhMin,
            "ph_max" to clampedPhMax,
            "tds_min" to clampedTdsMin,
            "tds_max" to clampedTdsMax
        )

        db.collection("ecoasis").document("settings")
            .set(settingsData)
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener { exception ->
                onFailure(exception)
            }
    }
    private fun clampPhValue(value: Double): Double {
        return value.coerceIn(PH_ABS_MIN, PH_ABS_MAX)
    }

    private fun clampTdsValue(value: Int): Int {
        return value.coerceIn(TDS_ABS_MIN, TDS_ABS_MAX)
    }

    fun loginUser(
        email: String,
        password: String,
        onSuccess: (User) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        if (email.isBlank() || !isValidEmail(email)) {
            onFailure(Exception("Please enter a valid email"))
            return
        }

        if (password.isBlank() || password.length < 6) {
            onFailure(Exception("Password must be at least 6 characters"))
            return
        }

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val user = auth.currentUser
                    if (user != null) {
                        getUserDataFromFirestore(user.uid, onSuccess, onFailure)
                    } else {
                        onFailure(Exception("User not found"))
                    }
                } else {
                    onFailure(task.exception ?: Exception("Authentication failed"))
                }
            }
    }

    fun registerUser(
        email: String,
        firstName: String,
        lastName: String,
        username: String,
        password: String,
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        if (email.isBlank() || !isValidEmail(email)) {
            onFailure(Exception("Please enter a valid email"))
            return
        }

        if (firstName.isBlank()) {
            onFailure(Exception("First name is required"))
            return
        }

        if (lastName.isBlank()) {
            onFailure(Exception("Last name is required"))
            return
        }

        if (username.isBlank() || username.length < 3) {
            onFailure(Exception("Username must be at least 3 characters"))
            return
        }

        if (password.isBlank() || password.length < 6) {
            onFailure(Exception("Password must be at least 6 characters"))
            return
        }

        checkUsernameAvailability(username) { usernameAvailable ->
            if (usernameAvailable) {
                auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val firebaseUser = auth.currentUser
                            if (firebaseUser != null) {
                                val profileUpdates = UserProfileChangeRequest.Builder()
                                    .setDisplayName("$firstName $lastName")
                                    .build()

                                firebaseUser.updateProfile(profileUpdates)
                                    .addOnCompleteListener { profileTask ->
                                        if (profileTask.isSuccessful) {
                                            saveUserDataToFirestore(
                                                firebaseUser.uid,
                                                email,
                                                firstName,
                                                lastName,
                                                username,
                                                onSuccess,
                                                onFailure
                                            )
                                        } else {
                                            onFailure(
                                                profileTask.exception
                                                    ?: Exception("Profile update failed")
                                            )
                                        }
                                    }
                            } else {
                                onFailure(Exception("User creation failed"))
                            }
                        } else {
                            onFailure(task.exception ?: Exception("Registration failed"))
                        }
                    }
            } else {
                onFailure(Exception("Username already taken"))
            }
        }
    }

    private fun checkUsernameAvailability(username: String, callback: (Boolean) -> Unit) {
        db.collection("users")
            .whereEqualTo("username", username)
            .get()
            .addOnSuccessListener { documents ->
                callback(documents.isEmpty)
            }
            .addOnFailureListener {
                callback(true)
            }
    }

    private fun saveUserDataToFirestore(
        uid: String,
        email: String,
        firstName: String,
        lastName: String,
        username: String,
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        val user = hashMapOf(
            "uid" to uid,
            "firstName" to firstName,
            "lastName" to lastName,
            "email" to email,
            "username" to username,
            "createdAt" to Date(),
            "updatedAt" to Date()
        )

        db.collection("users").document(uid)
            .set(user)
            .addOnSuccessListener {
                onSuccess()
            }
            .addOnFailureListener { exception ->
                onFailure(exception)
            }
    }
    private fun getUserDataFromFirestore(
        uid: String,
        onSuccess: (User) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        db.collection("users").document(uid)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val user = document.toObject(User::class.java)
                    if (user != null) {
                        onSuccess(user)
                    } else {
                        onFailure(Exception("User data not found"))
                    }
                } else {
                    onFailure(Exception("User document not found"))
                }
            }
            .addOnFailureListener { exception ->
                onFailure(exception)
            }
    }
    fun isUserLoggedIn(): Boolean {
        return auth.currentUser != null
    }

    fun signOut() {
        auth.signOut()
    }

    fun sendPasswordResetEmail(
        email: String,
        onSuccess: () -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        if (email.isBlank() || !isValidEmail(email)) {
            onFailure(Exception("Please enter a valid email"))
            return
        }

        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    onSuccess()
                } else {
                    onFailure(task.exception ?: Exception("Password reset failed"))
                }
            }
    }

    suspend fun getSensorOne(): SensorData? {
        return try {
            sensorCollection.document("readings").get().await().toObject(SensorData::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun getSensorOneRealTime(onUpdate: (SensorData?) -> Unit) {
        sensorCollection.document("readings").addSnapshotListener { snapshot, error ->
            if (error != null) {
                onUpdate(null)
                return@addSnapshotListener
            }

            val sensorData = snapshot?.toObject(SensorData::class.java)
            onUpdate(sensorData)
        }
    }

    data class SensorData(
        val air: Double = 0.0,
        val h2o: Double = 0.0,
        val humid: Double = 0.0,
        val lux: Double = 0.0,
        val ph: Double = 0.0,
        val ppm: Int = 0,
        val up: Double = 0.0,
        val down: Double = 0.0,
        val a: Double = 0.0,
        val b: Double = 0.0,
        val timestamp: com.google.firebase.Timestamp? = null // Add this field
    ) {
        constructor() : this(0.0, 0.0, 0.0, 0.0, 0.0, 0, 0.0, 0.0, 0.0, 0.0, null)
    }

    data class StatusData(
        val pump_a: Boolean = false,
        val pump_b: Boolean = false,
        val pump_ph_up: Boolean = false,
        val pump_ph_down: Boolean = false
    ) {
        constructor() : this(false, false, false, false)
    }

    data class User(
        val uid: String = "",
        val email: String = "",
        val firstName: String = "",
        val lastName: String = "",
        val username: String = "",
        val createdAt: Date = Date(),
        val updatedAt: Date = Date()
    ) {
        constructor() : this("", "", "", "", "", Date(), Date())
    }

    private fun isValidEmail(email: String): Boolean {
        val pattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+".toRegex()
        return pattern.matches(email)
    }

    fun getAllPlants(
        onSuccess: (List<Pair<String, PlantPreset>>) -> Unit,
        onFailure: (Exception) -> Unit
    ) {
        db.collection("plants")
            .get()
            .addOnSuccessListener { documents ->
                val plants = mutableListOf<Pair<String, PlantPreset>>()
                for (document in documents) {
                    val plant = document.toObject(PlantPreset::class.java)
                    plants.add(Pair(document.id, plant))
                }
                onSuccess(plants)
            }
            .addOnFailureListener { exception ->
                onFailure(exception)
            }
    }

}