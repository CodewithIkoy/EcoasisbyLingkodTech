package com.nu.ecoasis

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.Date
import java.util.concurrent.TimeUnit

import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequest
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters



class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Restart notification checking after device reboot
            NotificationCheckWorker.schedule(context)
        }
    }
}
class NotificationCheckWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            // Check for new notifications
            UnifiedNotificationService.forceCheckNow(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        private const val WORK_NAME = "notification_check_worker"

        fun schedule(context: Context) {
            val workRequest: PeriodicWorkRequest =
                PeriodicWorkRequestBuilder<NotificationCheckWorker>(
                    30, TimeUnit.MINUTES, // Every 30 minutes
                    15, TimeUnit.MINUTES  // Flexible interval
                ).build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP, // Keep existing schedule
                workRequest
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
class UnifiedNotificationService : FirebaseMessagingService() {

    private val notificationManager by lazy {
        getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    }

    companion object {
        private const val CHANNEL_ID = "ecoasis_alerts"
        private val shownNotificationIds = mutableSetOf<Int>()
        private var lastCheckedTime: Date = Date(0)

        // Use WorkManager for background checking
        fun scheduleBackgroundChecks(context: Context) {
            NotificationCheckWorker.schedule(context)
        }

        fun stopBackgroundChecks(context: Context) {
            NotificationCheckWorker.cancel(context)
        }

        suspend fun checkForNewNotifications(context: Context) {
            val db = Firebase.firestore

            try {
                val query = db.collection("notifications")
                    .whereGreaterThan("timestamp", lastCheckedTime)
                    .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                    .limit(20)

                val result = query.get().await()

                if (!result.isEmpty) {
                    result.documents.reversed().forEach { document ->
                        handleNewNotification(context, document)
                    }

                    // Update last checked time
                    val latestDoc = result.documents.firstOrNull()
                    latestDoc?.getTimestamp("timestamp")?.toDate()?.let { timestamp ->
                        lastCheckedTime = timestamp
                    }
                }
            } catch (e: Exception) {
                println("Error checking notifications: ${e.message}")
            }
        }

        // Make this public for Workers
        fun forceCheckNow(context: Context) {
            CoroutineScope(Dispatchers.IO).launch {
                checkForNewNotifications(context)
            }
        }


        private fun handleNewNotification(context: Context, document: com.google.firebase.firestore.DocumentSnapshot) {
            val notificationId = document.id
            val title = document.getString("title") ?: "Ecoasis Alert"
            val content = document.getString("content") ?: "New notification"
            val type = document.getString("type") ?: "general"
            val timestamp = document.getTimestamp("timestamp")?.toDate() ?: Date()

            // Skip if notification is too old (more than 24 hours)
            if (Date().time - timestamp.time > TimeUnit.HOURS.toMillis(24)) {
                return
            }

            // Show system notification
            showSystemNotification(context, notificationId, title, content, type)
        }

        private fun showSystemNotification(context: Context, id: String, title: String, content: String, type: String) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notificationId = generateNotificationId(id)

            // Avoid duplicates
            if (shownNotificationIds.contains(notificationId)) {
                return
            }

            val intent = Intent(context, NotificationsActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("from_notification", true)
            }

            val pendingIntent = PendingIntent.getActivity(
                context, notificationId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val channelId = "ecoasis_alerts"
            val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val notification = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(getNotificationIcon(type))
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setSound(defaultSoundUri)
                .setStyle(NotificationCompat.BigTextStyle().bigText(content))
                .build()

            notificationManager.notify(notificationId, notification)
            shownNotificationIds.add(notificationId)

            // Clean up old IDs to prevent memory issues
            if (shownNotificationIds.size > 100) {
                shownNotificationIds.clear()
            }
        }

        private fun getNotificationIcon(type: String): Int {
            return when (type) {
                "ph_alert", "nutrient_alert", "system_alert" -> R.drawable.ic_seedling_solid
                "system_normal" -> R.drawable.ic_seedling_solid
                else -> R.drawable.ic_seedling_solid
            }
        }

        private fun generateNotificationId(id: String): Int {
            return id.hashCode() and 0x7fffffff // Ensure positive
        }

    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        // Handle FCM messages (both data and notification payloads)
        handleRemoteMessage(remoteMessage)
    }

    override fun onNewToken(token: String) {
        // Handle token refresh if needed
        println("FCM Token refreshed: $token")
    }

    private fun handleRemoteMessage(remoteMessage: RemoteMessage) {
        val title: String
        val message: String
        val type: String

        // Priority: data payload > notification payload
        if (remoteMessage.data.isNotEmpty()) {
            title = remoteMessage.data["title"] ?: "Ecoasis Alert"
            message = remoteMessage.data["message"] ?: remoteMessage.data["content"] ?: "New system notification"
            type = remoteMessage.data["type"] ?: "general"
        } else {
            // Fallback to notification payload
            title = remoteMessage.notification?.title ?: "Ecoasis Alert"
            message = remoteMessage.notification?.body ?: "New system notification"
            type = "general"
        }

        showFcmNotification(title, message, type)
    }

    private fun showFcmNotification(title: String, message: String, type: String) {
        val notificationId = generateNotificationId(title + message + System.currentTimeMillis())

        // Avoid duplicates
        if (shownNotificationIds.contains(notificationId)) {
            return
        }

        val intent = Intent(this, NotificationsActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("from_notification", true)
        }

        val pendingIntent = PendingIntent.getActivity(
            this, notificationId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(getNotificationIcon(type))
            .setContentTitle(title)
            .setContentText(message)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))

        notificationManager.notify(notificationId, notificationBuilder.build())
        shownNotificationIds.add(notificationId)

        // Clean up old IDs to prevent memory issues
        if (shownNotificationIds.size > 100) {
            shownNotificationIds.clear()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ecoasis Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "System alerts and notifications from Ecoasis"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 250, 500)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }
}