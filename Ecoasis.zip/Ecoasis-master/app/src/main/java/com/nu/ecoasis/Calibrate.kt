package com.nu.ecoasis

import android.animation.ObjectAnimator
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.nu.ecoasis.databinding.ActivityCalibrateBinding
import com.nu.ecoasis.databinding.ActivitySettingsBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout

class CalibrateViewModel : ViewModel() {
    private val firestoreManager = FirestoreCalibrationManager()
    private val firestoreMainManager = FirestoreManager()
    private val _calibrationValues = MutableStateFlow<FirestoreCalibrationManager.CalibrationValues?>(null)
    private val _requestStatus = MutableStateFlow<Map<String, Boolean>?>(null)
    private val _calibrationStatus = MutableStateFlow<FirestoreManager.CalibrationStatus?>(null)
    private val _calibrationComplete = MutableStateFlow<Boolean>(false)
    private val _isCalibrating = MutableStateFlow<String?>(null)

    val calibrationValues: StateFlow<FirestoreCalibrationManager.CalibrationValues?> = _calibrationValues
    val requestStatus: StateFlow<Map<String, Boolean>?> = _requestStatus
    val calibrationStatus: StateFlow<FirestoreManager.CalibrationStatus?> = _calibrationStatus
    val calibrationComplete: StateFlow<Boolean> = _calibrationComplete
    val isCalibrating: StateFlow<String?> = _isCalibrating

    init {
        startListening()
        startListeningToRequests()
        startListeningToCalibrationStatus()
        startListeningToCalibrationCompletion()
    }

    private fun startListeningToCalibrationCompletion() {
        viewModelScope.launch {
            firestoreMainManager.getCalibrationCompletionRealTime { isComplete ->
                _calibrationComplete.value = isComplete
            }
        }
    }

    private fun startListeningToCalibrationStatus() {
        viewModelScope.launch {
            firestoreMainManager.getCalibrationStatusRealTime { status ->
                _calibrationStatus.value = status
            }
        }
    }

    fun setCalibrationRequest(phType: String) {
        viewModelScope.launch {
            _isCalibrating.value = phType

            firestoreManager.setCalibrationComplete(false)

            val success = firestoreManager.setRequestValue(phType, true)

            if (success) {
                val calibratedValue = firestoreManager.monitorPhVoltageForCalibration(phType, 15)

                calibratedValue?.let { phValue ->
                    val saveSuccess = firestoreManager.saveCalibrationValue(phType, phValue)
                    if (saveSuccess) {
                        firestoreMainManager.updateCalibrationCompletion()
                    }
                }

                firestoreManager.setRequestValue(phType, false)
            }

            _isCalibrating.value = null
        }
    }

    private fun startListening() {
        viewModelScope.launch {
            firestoreManager.listenForCalibrationUpdates(
                onUpdate = { values ->
                    _calibrationValues.value = values
                },
                onError = { error ->
                    error.printStackTrace()
                }
            )
        }
    }
    private fun startListeningToRequests() {
        viewModelScope.launch {
            firestoreManager.listenForRequestUpdates(
                onUpdate = { requests ->
                    _requestStatus.value = requests
                },
                onError = { error ->
                    error.printStackTrace()
                }
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        firestoreManager.stopListening()
    }
}
class FirestoreCalibrationManager {
    private val db = FirebaseFirestore.getInstance()
    private val calibrationRef = db.collection("ecoasis").document("calibration")
    private val readingsRef = db.collection("ecoasis").document("readings")
    private var listener: ListenerRegistration? = null
    private var requestListener: ListenerRegistration? = null
    private var readingsListener: ListenerRegistration? = null

    data class CalibrationValues(
        val ph4: Double? = null,
        val ph7: Double? = null,
        val ph9: Double? = null
    )
    suspend fun setCalibrationComplete(isComplete: Boolean): Boolean {
        return try {
            val updateData = hashMapOf<String, Any>(
                "complete" to isComplete
            )
            calibrationRef.update(updateData).await()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    suspend fun setRequestValue(phType: String, value: Boolean = true): Boolean {
        return try {
            val updateData = hashMapOf<String, Any>(
                "request.$phType" to value
            )
            calibrationRef.update(updateData).await()

            if (!value) {
                checkAndUpdateCompletion()
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private suspend fun checkAndUpdateCompletion() {
        try {
            val document = calibrationRef.get().await()
            if (document.exists()) {
                val requestMap = document.get("request") as? Map<String, Boolean> ?: emptyMap()

                val ph4Calibrated = requestMap["ph4"] == false
                val ph7Calibrated = requestMap["ph7"] == false
                val ph9Calibrated = requestMap["ph9"] == false

                val isComplete = ph4Calibrated && ph7Calibrated && ph9Calibrated

                val currentComplete = document.getBoolean("complete") ?: false
                if (isComplete != currentComplete) {
                    calibrationRef.update("complete", isComplete).await()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
    suspend fun saveCalibrationValue(phType: String, phValue: Double): Boolean {
        return try {
            val updateData = hashMapOf<String, Any>(
                "values.$phType" to phValue
            )
            calibrationRef.update(updateData).await()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun monitorPhVoltageForCalibration(phType: String, timeoutSeconds: Int = 15): Double? {
        return try {
            var calibratedValue: Double? = null
            var monitoring = true
            val timeoutMs = timeoutSeconds * 1000L

            val phVListener = readingsRef.addSnapshotListener { snapshot, error ->
                if (!monitoring) return@addSnapshotListener
                snapshot?.getDouble("ph_v")?.let { phV ->
                    calibratedValue = phV
                }
            }

            val calibrationCompleteListener = db.collection("ecoasis").document("readings")
                .addSnapshotListener { snapshot, error ->
                    if (!monitoring) return@addSnapshotListener
                    snapshot?.getBoolean("calibrating")?.let { calibrationComplete ->
                        if (!calibrationComplete) {
                            monitoring = false
                        }
                    }
                }

            val requestListener = calibrationRef.addSnapshotListener { snapshot, error ->
                if (!monitoring) return@addSnapshotListener
                (snapshot?.get("request") as? Map<String, Boolean>)?.get(phType)?.let { currentRequest ->
                    if (!currentRequest) {
                        monitoring = false
                    }
                }
            }

            try {
                withTimeout(timeoutMs) {
                    while (monitoring) {
                        delay(500)
                    }
                }
            } catch (e: TimeoutCancellationException) {
                monitoring = false
            }

            phVListener.remove()
            calibrationCompleteListener.remove()
            requestListener.remove()

            calibratedValue
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
    fun listenForRequestUpdates(
        onUpdate: (Map<String, Boolean>) -> Unit,
        onError: (Exception) -> Unit = {}
    ) {
        requestListener = calibrationRef.addSnapshotListener { snapshot, error ->
            error?.let {
                onError(it)
                return@addSnapshotListener
            }

            snapshot?.let { document ->
                if (document.exists() && document.contains("request")) {
                    val requestMap = document.get("request") as? Map<String, Boolean>
                    onUpdate(requestMap ?: emptyMap())
                }
            }
        }
    }

    suspend fun getRequestStatus(): Map<String, Boolean> {
        return try {
            val document = calibrationRef.get().await()
            if (document.exists() && document.contains("request")) {
                document.get("request") as? Map<String, Boolean> ?: emptyMap()
            } else {
                emptyMap()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyMap()
        }
    }

    suspend fun getCalibrationValues(): CalibrationValues? {
        return try {
            val document = calibrationRef.get().await()
            if (document.exists() && document.contains("values")) {
                val valuesMap = document.get("values") as? Map<String, Any>
                CalibrationValues(
                    ph4 = extractDouble(valuesMap, "ph4"),
                    ph7 = extractDouble(valuesMap, "ph7"),
                    ph9 = extractDouble(valuesMap, "ph9")
                )
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun extractDouble(map: Map<String, Any>?, key: String): Double? {
        return when (val value = map?.get(key)) {
            is Double -> value
            is Long -> value.toDouble()
            is Int -> value.toDouble()
            is Float -> value.toDouble()
            is String -> value.toDoubleOrNull()
            else -> null
        }
    }

    fun listenForCalibrationUpdates(
        onUpdate: (CalibrationValues) -> Unit,
        onError: (Exception) -> Unit = {}
    ) {
        listener = calibrationRef.addSnapshotListener { snapshot, error ->
            error?.let {
                onError(it)
                return@addSnapshotListener
            }

            snapshot?.let { document ->
                if (document.exists() && document.contains("values")) {
                    val valuesMap = document.get("values") as? Map<String, Any>
                    val values = CalibrationValues(
                        ph4 = extractDouble(valuesMap, "ph4"),
                        ph7 = extractDouble(valuesMap, "ph7"),
                        ph9 = extractDouble(valuesMap, "ph9")
                    )
                    onUpdate(values)
                }
            }
        }
    }

    fun stopListening() {
        listener?.remove()
        requestListener?.remove()
        readingsListener?.remove()
        listener = null
        requestListener = null
        readingsListener = null
    }
}
class Calibrate : AppCompatActivity() {
    private lateinit var btnPh4: Button
    private lateinit var btnPh7: Button
    private lateinit var btnPh9: Button
    private lateinit var phCalibratedText: TextView
    private lateinit var phVoltageText: TextView
    private val viewModel: CalibrateViewModel by viewModels()
    private lateinit var binding: ActivityCalibrateBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCalibrateBinding.inflate(layoutInflater)
        setContentView(binding.root)
        enableEdgeToEdge()

        btnPh4 = findViewById(R.id.btnph4)
        btnPh7 = findViewById(R.id.btnph7)
        btnPh9 = findViewById(R.id.btnph9)
        phCalibratedText = findViewById(R.id.phCalibratedText)
        phVoltageText = findViewById(R.id.phVoltageText)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setupButtonListeners()
        setupObservers()

        val backbutton: ImageButton = findViewById(R.id.backbutton)
        backbutton.setOnClickListener {
            val intent = Intent(this, Settings::class.java)
            startActivity(intent)
        }

        val settingsButton: ImageButton = findViewById(R.id.settingbtn)
        settingsButton.setOnClickListener {
            val intent = Intent(this, Settings::class.java)
            startActivity(intent)
        }
        updateButtonStates()
    }
    private fun startRotationAnimation(imageView: ImageView) {
        val rotateAnimation = ObjectAnimator.ofFloat(imageView, "rotation", 0f, 360f).apply {
            duration = 1000
            repeatCount = ObjectAnimator.INFINITE
            interpolator = LinearInterpolator()
        }
        rotateAnimation.start()
        imageView.tag = rotateAnimation
    }

    private fun stopRotationAnimation(imageView: ImageView) {
        (imageView.tag as? ObjectAnimator)?.cancel()
        imageView.rotation = 0f
        imageView.tag = null
    }
    private fun setupButtonListeners() {
        btnPh4.setOnClickListener {
            if (viewModel.isCalibrating.value == null) {
                viewModel.setCalibrationRequest("ph4")
            }
        }

        btnPh7.setOnClickListener {
            if (viewModel.isCalibrating.value == null) {
                viewModel.setCalibrationRequest("ph7")
            }
        }

        btnPh9.setOnClickListener {
            if (viewModel.isCalibrating.value == null) {
                viewModel.setCalibrationRequest("ph9")
            }
        }
    }

    private fun setupObservers() {

        lifecycleScope.launch {
            viewModel.requestStatus.collect { requests ->
                requests?.let { updateButtonStates(it) }
            }
        }

        lifecycleScope.launch {
            viewModel.calibrationStatus.collect { status ->
                status?.let { updateCalibrationStatus(it) }
            }
        }

        lifecycleScope.launch {
            viewModel.calibrationComplete.collect { isComplete ->
                updateCalibrationCompletionUI(isComplete)
            }
        }

        lifecycleScope.launch {
            viewModel.isCalibrating.collect { calibratingPh ->
                updateCalibrationProgress(calibratingPh)
            }
        }
    }



    private fun updateButtonStates(requests: Map<String, Boolean>) {
        val isCalibrating = viewModel.isCalibrating.value

        requests["ph4"]?.let { isRequested ->
            if (isCalibrating == "ph4") {
                btnPh4.text = "Reading"
                btnPh4.isEnabled = false
            } else if (isRequested) {
                btnPh4.text = "Set"
                btnPh4.isEnabled = true
            } else {
                btnPh4.text = "Set"
                btnPh4.isEnabled = true
            }
        } ?: run {
            btnPh4.text = "Set"
            btnPh4.isEnabled = isCalibrating == null
        }

        requests["ph7"]?.let { isRequested ->
            if (isCalibrating == "ph7") {
                btnPh7.text = "Reading"
                btnPh7.isEnabled = false
            } else if (isRequested) {
                btnPh7.text = "Set"
                btnPh7.isEnabled = true
            } else {
                btnPh7.text = "Set"
                btnPh7.isEnabled = true
            }
        } ?: run {
            btnPh7.text = "Set"
            btnPh7.isEnabled = isCalibrating == null
        }

        requests["ph9"]?.let { isRequested ->
            if (isCalibrating == "ph9") {
                btnPh9.text = "Reading"
                btnPh9.isEnabled = false
            } else if (isRequested) {
                btnPh9.text = "Set"
                btnPh9.isEnabled = true
            } else {
                btnPh9.text = "Set"
                btnPh9.isEnabled = true
            }
        } ?: run {
            btnPh9.text = "Set"
            btnPh9.isEnabled = isCalibrating == null
        }
    }

    private fun updateCalibrationProgress(calibratingPh: String?) {
        val calibrateAnim: ImageView = findViewById(R.id.calibrateanim)

        calibratingPh?.let { phType ->
            startRotationAnimation(calibrateAnim)

            when (phType) {
                "ph4" -> {
                    btnPh4.text = "Reading"
                    btnPh4.isEnabled = false
                }
                "ph7" -> {
                    btnPh7.text = "Reading"
                    btnPh7.isEnabled = false
                }
                "ph9" -> {
                    btnPh9.text = "Reading"
                    btnPh9.isEnabled = false
                }
            }

            when (phType) {
                "ph4" -> {
                    btnPh7.isEnabled = false
                    btnPh9.isEnabled = false
                }
                "ph7" -> {
                    btnPh4.isEnabled = false
                    btnPh9.isEnabled = false
                }
                "ph9" -> {
                    btnPh4.isEnabled = false
                    btnPh7.isEnabled = false
                }
            }
        } ?: run {
            stopRotationAnimation(calibrateAnim)

            btnPh4.isEnabled = true
            btnPh7.isEnabled = true
            btnPh9.isEnabled = true

            btnPh4.text = "Set"
            btnPh7.text = "Set"
            btnPh9.text = "Set"
        }
    }

    private fun updateCalibrationStatus(status: FirestoreManager.CalibrationStatus) {
        if (status.calibrationComplete) {
            phCalibratedText.text = "YES"
            phCalibratedText.setTextColor(ContextCompat.getColor(this, R.color.green_success))
        } else {
            phCalibratedText.text = "NO"
            phCalibratedText.setTextColor(ContextCompat.getColor(this, R.color.red_error))
        }

        phVoltageText.text = String.format("%.2f", status.getPhVoltage())
    }

    private fun updateCalibrationCompletionUI(isComplete: Boolean) {
        if (isComplete) {
            showCalibrationCompleteMessage()
            phCalibratedText.text = "YES"
            phCalibratedText.setTextColor(ContextCompat.getColor(this, R.color.green_success))
        }

    }

    private fun showCalibrationCompleteMessage() {
        android.widget.Toast.makeText(
            this,
            "Calibration Complete! All pH values have been calibrated.",
            android.widget.Toast.LENGTH_LONG
        ).show()
    }

    private fun updateButtonStates() {
        val isNightMode = isNightModeEnabled()
        binding.settingbtn?.isActivated = isNightMode
        binding.backbutton.isActivated = isNightMode
    }

    private fun isNightModeEnabled(): Boolean {
        val currentNightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return currentNightMode == Configuration.UI_MODE_NIGHT_YES
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateButtonStates()
    }
    override fun onDestroy() {
        super.onDestroy()
        val calibrateAnim: ImageView = findViewById(R.id.calibrateanim)
        stopRotationAnimation(calibrateAnim)
    }
}