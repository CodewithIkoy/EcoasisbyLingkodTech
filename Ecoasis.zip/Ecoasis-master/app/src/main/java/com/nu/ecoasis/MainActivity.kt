package com.nu.ecoasis

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CompoundButton
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar

object StatusUtils {
    fun getStatusText(status: Int): String {
        return when (status) {
            1 -> "LOW"
            2 -> "IN RANGE"
            3 -> "HIGH"
            else -> "- - -"
        }
    }
}

data class SensorUiState(
    val air: Double = 0.0,
    val h2o: Double = 0.0,
    val humid: Double = 0.0,
    val lux: Double = 0.0,
    val ph: Double = 0.0,
    val ppm: Int = 0,
    val up: Double = 0.0,
    val down: Double = 0.0,
    val a: Double = 0.0,
    val b: Double = 0.0,
    val isLoading: Boolean = true,
    val error: String? = null,
    val pumpA: Boolean = false,
    val pumpB: Boolean = false,
    val pumpDown: Boolean = false,
    val pumpUp: Boolean = false,
    val phStatus: Int = 0,
    val ppmStatus: Int = 0
)

class SensorViewModel(private val firestoreManager: FirestoreManager) : ViewModel() {

    private val _uiState = MutableStateFlow(SensorUiState())
    val uiState: StateFlow<SensorUiState> = _uiState.asStateFlow()
    private val _connectionStatus = MutableLiveData<Boolean>()
    val connectionStatus: LiveData<Boolean> = _connectionStatus
    private var lastUpdateTime: Long = 0L
    private val CONNECTION_TIMEOUT_MS = 30000L
    init {
        loadSensorData()
        loadPumpStatus()
        loadStatusReading()
        setupRealTimeUpdates()
        setupPumpStatusRealTime()
        setupStatusReadingRealTime()
    }
    private fun checkConnectionStatus(sensorData: FirestoreManager.SensorData?) {
        val isConnected = if (sensorData?.timestamp != null) {
            val sensorTime = sensorData.timestamp.toDate().time
            val currentTime = System.currentTimeMillis()
            val timeDifference = currentTime - sensorTime

            lastUpdateTime = sensorTime
            timeDifference <= CONNECTION_TIMEOUT_MS
        } else {
            false
        }

        _connectionStatus.value = isConnected
    }
    private fun loadStatusReading() {
        viewModelScope.launch {
            try {
                val statusReading = firestoreManager.getStatusReading()
                statusReading?.let {
                    _uiState.update { currentState ->
                        currentState.copy(
                            phStatus = it.status.ph,
                            ppmStatus = it.status.tds
                        )
                    }
                }
            } catch (e: Exception) {
                // Handle error silently for status reading
            }
        }
    }

    private fun setupStatusReadingRealTime() {
        firestoreManager.getStatusReadingRealTime { statusReading ->
            statusReading?.let {
                _uiState.update { currentState ->
                    currentState.copy(
                        phStatus = it.status.ph,
                        ppmStatus = it.status.tds
                    )
                }
            }
        }
    }

    private fun loadPumpStatus() {
        viewModelScope.launch {
            try {
                val statusData = firestoreManager.getPumpStatus()
                statusData?.let {
                    _uiState.update { currentState ->
                        currentState.copy(
                            pumpA = it.pump_a,
                            pumpB = it.pump_b,
                            pumpUp = it.pump_ph_up,
                            pumpDown = it.pump_ph_down
                        )
                    }
                }
            } catch (e: Exception) {
                // Handle error silently for pump status
            }
        }
    }

    private fun setupPumpStatusRealTime() {
        firestoreManager.getPumpStatusRealTime { statusData ->
            statusData?.let {
                _uiState.update { currentState ->
                    currentState.copy(
                        pumpA = it.pump_a,
                        pumpB = it.pump_b,
                        pumpUp = it.pump_ph_up,
                        pumpDown = it.pump_ph_down
                    )
                }
            }
        }
    }


    private fun loadSensorData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }

            try {
                val sensorData = firestoreManager.getSensorOne()
                sensorData?.let {
                    _uiState.update { currentState ->
                        currentState.copy(
                            air = it.air,
                            h2o = it.h2o,
                            humid = it.humid,
                            lux = it.lux,
                            ph = it.ph,
                            ppm = it.ppm,
                            up = it.up,
                            down = it.down,
                            a = it.a,
                            b = it.b,
                            isLoading = false,
                            error = null
                        )
                    }
                    checkConnectionStatus(it)
                } ?: run {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            error = "No sensor data available"
                        )
                    }
                    _connectionStatus.value = false
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        error = "Failed to load sensor data: ${e.message}"
                    )
                }
                _connectionStatus.value = false
            }
        }
    }

    private fun setupRealTimeUpdates() {
        firestoreManager.getSensorOneRealTime { sensorData ->
            sensorData?.let {
                _uiState.update { currentState ->
                    currentState.copy(
                        air = it.air,
                        h2o = it.h2o,
                        humid = it.humid,
                        lux = it.lux,
                        ph = it.ph,
                        ppm = it.ppm,
                        up = it.up,
                        down = it.down,
                        a = it.a,
                        b = it.b,
                        isLoading = false,
                        error = null
                    )
                }
                checkConnectionStatus(it)
            } ?: run {
                _connectionStatus.value = false
            }
        }
    }

    fun refreshData() {
        loadSensorData()
    }

    fun clearError() {
        _uiState.update { it.copy(error = null) }
    }
}

class SensorViewModelFactory(private val firestoreManager: FirestoreManager) :
    ViewModelProvider.Factory {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SensorViewModel::class.java)) {
            return SensorViewModel(firestoreManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class SettingsDialog(context: Context) : Dialog(context) {

    private lateinit var darkModeSwitch: com.google.android.material.switchmaterial.SwitchMaterial
    private lateinit var logoutOption: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.popup_settings)

        window?.setBackgroundDrawableResource(android.R.color.transparent)
        window?.setLayout(
            (context.resources.displayMetrics.widthPixels * 0.9).toInt(),
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT
        )

        initializeViews()
        setupClickListeners()
        loadCurrentSettings()

    }

    private fun initializeViews() {
        darkModeSwitch = findViewById(R.id.darkModeSwitch)
        logoutOption = findViewById(R.id.logoutOption)
    }

    private fun setupClickListeners() {
        darkModeSwitch.setOnCheckedChangeListener { _: CompoundButton, isChecked: Boolean ->
            setDarkMode(isChecked)
        }

        logoutOption.setOnClickListener {
            performLogout()
            dismiss()
        }
    }

    private fun loadCurrentSettings() {
        val currentNightMode = context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        val isDarkMode = currentNightMode == Configuration.UI_MODE_NIGHT_YES
        darkModeSwitch.isChecked = isDarkMode
    }

    private fun setDarkMode(isDarkMode: Boolean) {
        val mode = if (isDarkMode) {
            AppCompatDelegate.MODE_NIGHT_YES
        } else {
            AppCompatDelegate.MODE_NIGHT_NO
        }
        AppCompatDelegate.setDefaultNightMode(mode)

        val sharedPref = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putBoolean("dark_mode", isDarkMode)
            apply()
        }
    }

    private fun performLogout() {
        val firestoreManager = FirestoreManager()
        firestoreManager.signOut()

        val intent = Intent(context, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        context.startActivity(intent)
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var sensorViewModel: SensorViewModel
    private lateinit var firestoreManager: FirestoreManager
    // UI Components
    private lateinit var tempval: TextView
    private lateinit var phval: TextView
    private lateinit var ppmval: TextView
    private lateinit var humidval: TextView
    private lateinit var airval: TextView
    private lateinit var dotStatus: ImageView
    private lateinit var textStatus: TextView
    private lateinit var upPumpButton: ImageButton
    private lateinit var downPumpButton: ImageButton
    private lateinit var aPumpButton: TextView
    private lateinit var bPumpButton: TextView
    private lateinit var phStatusText: TextView
    private lateinit var ppmStatusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.rootView)) { v, insets ->
            val imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, systemBars.top, 0, imeInsets.bottom)
            insets
        }

        // Initialize FirestoreManager FIRST
        firestoreManager = FirestoreManager() // ADD THIS LINE

        initializeViews()
        setupViewModel()
        setupClickListeners()
        updateButtonStates()


        checkNotificationPermission()
        initializeUnifiedNotifications()

        setupObservers()

        val textView3 = findViewById<TextView>(R.id.textView3)
        textView3.text = getGreetingBasedOnTime()
    }

    private fun initializeViews() {
        tempval = findViewById(R.id.temp_val)
        phval = findViewById(R.id.ph_val)
        ppmval = findViewById(R.id.ppm_val)
        humidval = findViewById(R.id.humid_val)
        airval = findViewById(R.id.air_val)
        dotStatus = findViewById(R.id.dot_status)
        textStatus = findViewById(R.id.text_status)
        upPumpButton = findViewById(R.id.up_pump)
        downPumpButton = findViewById(R.id.down_pump)
        aPumpButton = findViewById(R.id.a_pump_text)
        bPumpButton = findViewById(R.id.b_pump_text)
        phStatusText = findViewById(R.id.phStatusText)
        ppmStatusText = findViewById(R.id.ppmStatusText)
    }

    private fun setupViewModel() {
        val factory = SensorViewModelFactory(firestoreManager)
        sensorViewModel = ViewModelProvider(this, factory)[SensorViewModel::class.java]

        sensorViewModel.connectionStatus.observe(this) { isConnected ->
            updateStatusUI(isConnected)

        }
    }

    private fun setupClickListeners() {
        val settingsCard = findViewById<CardView>(R.id.settingsCard)
        settingsCard.setOnClickListener {
            showSettingsPopup()
        }

        val settingsButton: ImageButton = findViewById(R.id.settingbtn)
        settingsButton.setOnClickListener {
            val intent = Intent(this, Settings::class.java)
            startActivity(intent)
        }

        val notifBtn: ImageButton = findViewById(R.id.notifbtn)
        notifBtn.setOnClickListener {
            val intent = Intent(this, NotificationsActivity::class.java)
            startActivity(intent)
        }
    }

    private fun updateStatusUI(isConnected: Boolean) {
        if (isConnected) {
            dotStatus.setImageResource(R.drawable.ic_dot_green)
            textStatus.text = "Online"
            textStatus.setTextColor(ContextCompat.getColor(this, R.color.green))
        } else {
            dotStatus.setImageResource(R.drawable.ic_dot_red)
            textStatus.text = "Offline"
            textStatus.setTextColor(ContextCompat.getColor(this, R.color.red))
        }
    }

    private fun getGreetingBasedOnTime(): String {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)

        return when (hour) {
            in 5..11 -> "Good Morning!"
            in 12..17 -> "Good Afternoon!"
            in 18..21 -> "Good Evening!"
            else -> "Good Night!"
        }
    }

    private fun setupObservers() {
        lifecycleScope.launch {
            sensorViewModel.uiState.collect { uiState ->
                updateUI(uiState)
            }
        }
    }

    private fun updateUI(uiState: SensorUiState) {
        tempval.text = "${uiState.h2o}"
        phval.text = "${uiState.ph}"
        ppmval.text = "${uiState.ppm}"
        humidval.text = "${uiState.humid}"
        airval.text = "${uiState.air}"

        updatePumpButtonState(upPumpButton, uiState.pumpUp)
        updatePumpButtonState(downPumpButton, uiState.pumpDown)
        updatePumpButtonState(aPumpButton, uiState.pumpA)
        updatePumpButtonState(bPumpButton, uiState.pumpB)
        updateStatusDisplay(uiState.phStatus, uiState.ppmStatus)

        uiState.error?.let { error ->
            showErrorDialog(error)
        }
    }

    private fun updateStatusDisplay(phStatus: Int, ppmStatus: Int) {
        phStatusText.text = StatusUtils.getStatusText(phStatus)
        ppmStatusText.text = StatusUtils.getStatusText(ppmStatus)
    }

    private fun updatePumpButtonState(button: View, isActive: Boolean) {
        val context = button.context
        val activeColor = ContextCompat.getColor(context, R.color.themegreen)
        val inactiveColor = ContextCompat.getColor(context, R.color.textwhite)

        when (button) {
            is ImageButton -> {
                button.isActivated = isActive
            }
            is TextView -> {
                button.setTextColor(if (isActive) activeColor else inactiveColor)
            }
        }
    }

    private fun showSettingsPopup() {
        val settingsDialog = SettingsDialog(this)
        settingsDialog.show()
    }

    private fun showErrorDialog(message: String) {
        val toast = Toast.makeText(
            this,
            "❌ Error: $message",
            Toast.LENGTH_LONG
        )
        toast.setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, 100)
        toast.show()
    }

    private fun updateButtonStates() {
        val isNightMode = isNightModeEnabled()
        findViewById<ImageButton>(R.id.settingbtn).isActivated = isNightMode
        findViewById<ImageButton>(R.id.notifbtn).isActivated = isNightMode

        if (isNightMode) {
            upPumpButton.setImageResource(R.drawable.ic_up_selector_dark)
            downPumpButton.setImageResource(R.drawable.ic_down_selector_dark)
        } else {
            upPumpButton.setImageResource(R.drawable.ic_up_selector)
            downPumpButton.setImageResource(R.drawable.ic_down_selector)
        }
    }

    private fun isNightModeEnabled(): Boolean {
        val currentNightMode = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        return currentNightMode == Configuration.UI_MODE_NIGHT_YES
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        updateButtonStates()
    }
    private fun initializeUnifiedNotifications() {
        // Schedule background checking (works even when app is closed)
        UnifiedNotificationService.scheduleBackgroundChecks(this)

        // Also do an immediate check
        UnifiedNotificationService.forceCheckNow(this)

        // FCM for instant notifications
        FirebaseMessaging.getInstance().subscribeToTopic("ecoasis_alerts")

        checkNotificationPermission()
    }

    override fun onDestroy() {
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        // Force an immediate check when app comes to foreground
        UnifiedNotificationService.forceCheckNow(this)
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this,
                    android.Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    private fun handleIntentNotification(intent: Intent) {
        // Handle when app is opened from notification
        if (intent.extras?.containsKey("from_notification") == true) {
            // Navigate to notifications activity
            val notificationsIntent = Intent(this, NotificationsActivity::class.java)
            startActivity(notificationsIntent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntentNotification(intent)
    }
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            1001 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Notification permission granted
                    println("Notification permission granted")
                } else {
                    // Notification permission denied
                    println("Notification permission denied")
                }
            }
        }
    }
}